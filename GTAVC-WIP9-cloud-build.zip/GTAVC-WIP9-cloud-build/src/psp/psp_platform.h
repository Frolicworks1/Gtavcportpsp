#ifndef GTAVC_PSP_PLATFORM_H
#define GTAVC_PSP_PLATFORM_H
void gtavc_psp_platform_init(void);
void gtavc_psp_platform_frame(void);
void gtavc_psp_platform_shutdown(void);
#endif
