#include <pspiofilemgr.h>
#include <string.h>
#include <strings.h>
#include <stdio.h>
#include <stdint.h>
#include "psp_img.h"
#include "psp_fs.h"

#define GTA_IMG_SECTOR_SIZE 2048u
#define GTA_IMG_MAX_ENTRIES 8192
#define GTA_IMG_DIR_ENTRY_SIZE 32

static SceUID g_img_fd = -1;
static SceUID g_dir_fd = -1;
static int g_count;
static GtaImgEntry g_entries[GTA_IMG_MAX_ENTRIES];

static int read_u32_le(const unsigned char *p, uint32_t *out) {
    if (!p || !out) return -1;
    *out = (uint32_t)p[0] | ((uint32_t)p[1] << 8) |
           ((uint32_t)p[2] << 16) | ((uint32_t)p[3] << 24);
    return 0;
}
static int read_u16_le(const unsigned char *p, uint16_t *out) {
    if (!p || !out) return -1;
    *out = (uint16_t)p[0] | ((uint16_t)p[1] << 8);
    return 0;
}

int gtavc_psp_img_open(const char *relative_img_path) {
    char img_path[512], dir_path[512];
    size_t n;
    gtavc_psp_img_close();
    if (!relative_img_path) return -1;
    if (snprintf(img_path, sizeof(img_path), "%s/%s", gtavc_psp_game_root(), relative_img_path) >= (int)sizeof(img_path)) return -2;
    n = strlen(img_path);
    if (n < 4 || strcasecmp(img_path + n - 4, ".img") != 0) return -3;
    if (n >= sizeof(dir_path)) return -2;
    memcpy(dir_path, img_path, n + 1);
    memcpy(dir_path + n - 4, ".dir", 5);

    g_img_fd = sceIoOpen(img_path, PSP_O_RDONLY, 0);
    if (g_img_fd < 0) return (int)g_img_fd;
    g_dir_fd = sceIoOpen(dir_path, PSP_O_RDONLY, 0);
    if (g_dir_fd < 0) { gtavc_psp_img_close(); return (int)g_dir_fd; }

    g_count = 0;
    for (;;) {
        unsigned char raw[GTA_IMG_DIR_ENTRY_SIZE];
        int got = sceIoRead(g_dir_fd, raw, sizeof(raw));
        if (got == 0) break;
        if (got < 0 || got != (int)sizeof(raw)) { gtavc_psp_img_close(); return -4; }
        if (g_count >= GTA_IMG_MAX_ENTRIES) { gtavc_psp_img_close(); return -5; }
        GtaImgEntry *e = &g_entries[g_count];
        read_u32_le(raw, &e->sector);
        read_u16_le(raw + 4, &e->sectors);
        memcpy(e->name, raw + 8, 24);
        e->name[24] = '\0';
        g_count++;
    }
    if (g_count == 0) { gtavc_psp_img_close(); return -6; }
    return g_count;
}

void gtavc_psp_img_close(void) {
    if (g_dir_fd >= 0) sceIoClose(g_dir_fd);
    if (g_img_fd >= 0) sceIoClose(g_img_fd);
    g_dir_fd = -1;
    g_img_fd = -1;
    g_count = 0;
}

int gtavc_psp_img_count(void) { return g_count; }

int gtavc_psp_img_find(const char *name, GtaImgEntry *out) {
    if (!name) return -1;
    for (int i = 0; i < g_count; ++i) {
        if (strcasecmp(g_entries[i].name, name) == 0) {
            if (out) *out = g_entries[i];
            return i;
        }
    }
    return -1;
}

int gtavc_psp_img_read(const GtaImgEntry *entry, uint32_t offset, void *dst,
                       size_t bytes, size_t *out_read) {
    uint64_t start, capacity;
    int seek_result, got;
    if (out_read) *out_read = 0;
    if (!entry || !dst || g_img_fd < 0) return -1;
    capacity = (uint64_t)entry->sectors * GTA_IMG_SECTOR_SIZE;
    if ((uint64_t)offset > capacity || (uint64_t)bytes > capacity - offset) return -2;
    start = (uint64_t)entry->sector * GTA_IMG_SECTOR_SIZE + offset;
    if (start > 0x7fffffffULL) return -3;
    seek_result = sceIoLseek(g_img_fd, (SceOff)start, PSP_SEEK_SET) < 0 ? -1 : 0;
    if (seek_result < 0) return seek_result;
    got = sceIoRead(g_img_fd, dst, bytes);
    if (got < 0) return got;
    if (out_read) *out_read = (size_t)got;
    return 0;
}
