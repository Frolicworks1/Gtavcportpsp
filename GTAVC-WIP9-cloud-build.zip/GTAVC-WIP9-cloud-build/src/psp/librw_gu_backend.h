#ifndef GTAVC_LIBRW_GU_BACKEND_H
#define GTAVC_LIBRW_GU_BACKEND_H
#ifdef __cplusplus
extern "C" {
#endif
int gtavc_librw_gu_init(void);
void gtavc_librw_gu_begin(void);
void gtavc_librw_gu_end(void);
void gtavc_librw_gu_shutdown(void);
#ifdef __cplusplus
}
#endif
#endif
