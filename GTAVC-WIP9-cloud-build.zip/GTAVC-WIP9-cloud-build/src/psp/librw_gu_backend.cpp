#include <pspgu.h>
#include <pspdisplay.h>
#include <string.h>
#include "librw_gu_backend.h"
static unsigned int __attribute__((aligned(16))) s_list[131072];
static int s_ready;
int gtavc_librw_gu_init(void){
    if(s_ready) return 0;
    sceGuInit();
    sceGuStart(GU_DIRECT,s_list);
    sceGuDrawBuffer(GU_PSM_8888,(void*)0,512);
    sceGuDispBuffer(480,272,(void*)0x88000,512);
    sceGuDepthBuffer((void*)0x110000,512);
    sceGuOffset(2048-240,2048-136);
    sceGuViewport(2048,2048,480,272);
    sceGuScissor(0,0,480,272);
    sceGuEnable(GU_SCISSOR_TEST);
    sceGuDisable(GU_CULL_FACE);
    sceGuDisable(GU_DEPTH_TEST);
    sceGuFinish(); sceGuSync(0,0); sceDisplayWaitVblankStart(); sceGuDisplay(GU_TRUE);
    s_ready=1; return 0;
}
void gtavc_librw_gu_begin(void){ if(!s_ready)return; sceGuStart(GU_DIRECT,s_list); sceGuClearColor(0xff101018); sceGuClear(GU_COLOR_BUFFER_BIT); }
void gtavc_librw_gu_end(void){ if(!s_ready)return; sceGuFinish(); sceGuSync(0,0); sceDisplayWaitVblankStart(); sceGuSwapBuffers(); }
void gtavc_librw_gu_shutdown(void){ if(!s_ready)return; sceGuDisplay(GU_FALSE); sceGuTerm(); s_ready=0; }
