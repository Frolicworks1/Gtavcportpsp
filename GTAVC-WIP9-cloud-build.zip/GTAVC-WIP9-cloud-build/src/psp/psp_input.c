#include <pspctrl.h>
#include "psp_input.h"
void gtavc_psp_input_init(void) {
    sceCtrlSetSamplingCycle(0);
    sceCtrlSetSamplingMode(PSP_CTRL_MODE_ANALOG);
}
SceCtrlData gtavc_psp_input_read(void) {
    SceCtrlData pad;
    sceCtrlPeekBufferPositive(&pad, 1);
    return pad;
}
