#ifndef GTAVC_PSP_LIBRW_H
#define GTAVC_PSP_LIBRW_H
#include <stddef.h>
#include <stdint.h>

int gtavc_psp_librw_init(void);
void gtavc_psp_librw_shutdown(void);
void gtavc_psp_librw_begin_frame(void);
void gtavc_psp_librw_end_frame(void);
void gtavc_psp_librw_draw_bootstrap(float angle);

#endif
