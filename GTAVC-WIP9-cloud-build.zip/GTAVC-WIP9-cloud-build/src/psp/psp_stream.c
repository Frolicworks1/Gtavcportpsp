#include <pspiofilemgr.h>
#include <stddef.h>
#include <string.h>
#include "psp_stream.h"
#include "psp_fs.h"

int gtavc_psp_stream_read(const char *path, void *buf, size_t size, size_t *out_read) {
    if (!path || !buf) return -1;
    return gtavc_psp_fs_read_file(path, buf, size, out_read);
}
