#ifndef GTAVC_PSP_STREAM_H
#define GTAVC_PSP_STREAM_H
#include <stddef.h>
int gtavc_psp_stream_read(const char *path, void *buf, size_t size, size_t *out_read);
#endif
