#ifndef GTAVC_REVC_PSP_PLATFORM_H
#define GTAVC_REVC_PSP_PLATFORM_H
#include <pspctrl.h>
#ifdef __cplusplus
extern "C" {
#endif
unsigned int gtavc_psp_timer_ms(void);
void gtavc_psp_poll_pad(SceCtrlData *out);
int gtavc_psp_open_external(const char *path, int flags);
#ifdef __cplusplus
}
#endif
#endif
