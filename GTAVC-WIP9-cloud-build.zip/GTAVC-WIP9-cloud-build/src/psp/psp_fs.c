#include <pspiofilemgr.h>
#include <stdio.h>
#include <string.h>
#include "psp_fs.h"

static char g_root[256] = "./";

static int exists(const char *path) {
    SceUID fd = sceIoOpen(path, PSP_O_RDONLY, 0);
    if (fd < 0) return 0;
    sceIoClose(fd);
    return 1;
}

static void join_path(char *out, size_t out_size, const char *root, const char *rel) {
    size_t n = strlen(root);
    if (n && root[n - 1] == '/')
        snprintf(out, out_size, "%s%s", root, rel);
    else
        snprintf(out, out_size, "%s/%s", root, rel);
}

int gtavc_psp_fs_init(void) {
    /* PPSSPP/homebrew normally starts with the EBOOT directory as cwd. */
    static const char *roots[] = {
        "./",
        "ms0:/PSP/GAME/GTAVC/",
        "ef0:/PSP/GAME/GTAVC/",
        "ms0:/GTAVC/",
        "ef0:/GTAVC/"
    };
    static const char *probes[] = {
        "models/gta3.img",
        "models/txd.img",
        "data/gta_vc.dat",
        "data/default.dat",
        "data/handling.cfg"
    };

    for (unsigned r = 0; r < sizeof(roots) / sizeof(roots[0]); ++r) {
        char path[256];
        for (unsigned p = 0; p < sizeof(probes) / sizeof(probes[0]); ++p) {
            join_path(path, sizeof(path), roots[r], probes[p]);
            if (exists(path)) {
                snprintf(g_root, sizeof(g_root), "%s", roots[r]);
                return 0;
            }
        }
    }
    /* Keep ./ as the default: the engine can still use a custom data layout. */
    snprintf(g_root, sizeof(g_root), "./");
    return -1;
}

const char *gtavc_psp_game_root(void) { return g_root; }

int gtavc_psp_fs_file_exists(const char *relative) {
    char path[512];
    if (!relative) return 0;
    join_path(path, sizeof(path), g_root, relative);
    return exists(path);
}

int gtavc_psp_fs_read_file(const char *relative, void *buf, size_t size, size_t *out_read) {
    char path[512];
    if (out_read) *out_read = 0;
    if (!relative || !buf) return -1;
    join_path(path, sizeof(path), g_root, relative);
    SceUID fd = sceIoOpen(path, PSP_O_RDONLY, 0);
    if (fd < 0) return (int)fd;
    int n = sceIoRead(fd, buf, size);
    sceIoClose(fd);
    if (n >= 0 && out_read) *out_read = (size_t)n;
    return n < 0 ? n : 0;
}

int gtavc_psp_fs_probe(void) {
    static const char *files[] = {
        "models/gta3.img",
        "models/txd.img",
        "models/cuts.img",
        "data/gta_vc.dat",
        "data/default.dat",
        "data/handling.cfg",
        "data/weapon.dat",
        "data/surfinfo.dat",
        "data/timecyc.dat",
        "data/water.dat",
        "data/peds.ide",
        "data/vehicles.ide",
        "data/paths.dat"
    };
    int found = 0;
    for (unsigned i = 0; i < sizeof(files) / sizeof(files[0]); ++i)
        found += gtavc_psp_fs_file_exists(files[i]);
    return found;
}
