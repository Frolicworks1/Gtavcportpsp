#ifndef GTAVC_PSP_SAVE_H
#define GTAVC_PSP_SAVE_H
int gtavc_psp_save_init(void);
#endif
