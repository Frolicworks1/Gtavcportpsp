#ifndef GTAVC_PSP_IMG_H
#define GTAVC_PSP_IMG_H
#include <stddef.h>
#include <stdint.h>

typedef struct {
    uint32_t sector;       /* offset in 2048-byte sectors in the .img file */
    uint16_t sectors;      /* allocated sector count from .dir */
    char name[25];         /* NUL-terminated entry name */
} GtaImgEntry;

/* Opens the .dir index paired with the supplied .img archive path. */
int gtavc_psp_img_open(const char *relative_img_path);
void gtavc_psp_img_close(void);
int gtavc_psp_img_count(void);
int gtavc_psp_img_find(const char *name, GtaImgEntry *out);
/* Reads the entry's allocated bytes (up to sectors*2048) from the .img. */
int gtavc_psp_img_read(const GtaImgEntry *entry, uint32_t offset, void *dst,
                       size_t bytes, size_t *out_read);
#endif
