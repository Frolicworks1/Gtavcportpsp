#ifndef GTAVC_PSP_INPUT_H
#define GTAVC_PSP_INPUT_H
#include <pspctrl.h>
void gtavc_psp_input_init(void);
SceCtrlData gtavc_psp_input_read(void);
#endif
