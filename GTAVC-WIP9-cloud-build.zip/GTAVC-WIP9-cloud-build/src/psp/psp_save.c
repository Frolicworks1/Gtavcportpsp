#include <pspiofilemgr.h>
#include "psp_save.h"
int gtavc_psp_save_init(void) {
    sceIoMkdir("ms0:/PSP/SAVEDATA/GTAVCPSP", 0777);
    return 0;
}
