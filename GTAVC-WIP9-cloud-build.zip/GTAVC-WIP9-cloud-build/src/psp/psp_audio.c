#include <pspaudio.h>
#include "psp_audio.h"
int gtavc_psp_audio_init(void) { return 0; }
void gtavc_psp_audio_shutdown(void) { }
