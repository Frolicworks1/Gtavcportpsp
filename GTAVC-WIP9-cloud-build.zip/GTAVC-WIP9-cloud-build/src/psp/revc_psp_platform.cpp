/* PSP platform adapter for the real reVC engine.
 * This file intentionally contains no game assets. It supplies the platform
 * boundary that desktop skeletons normally provide.
 */
#include <pspkernel.h>
#include <pspctrl.h>
#include <pspiofilemgr.h>
#include <pspsdk.h>
#include <time.h>
#include <string.h>
#include <stdlib.h>
#include "psp_platform.h"

extern "C" unsigned int gtavc_psp_timer_ms(void) {
    return (unsigned int)(sceKernelGetSystemTimeWide() / 1000ULL);
}

extern "C" void gtavc_psp_poll_pad(SceCtrlData *out) {
    if (!out) return;
    memset(out, 0, sizeof(*out));
    sceCtrlPeekBufferPositive(out, 1);
}

extern "C" int gtavc_psp_open_external(const char *path, int flags) {
    if (!path) return -1;
    return (int)sceIoOpen(path, flags, 0777);
}
