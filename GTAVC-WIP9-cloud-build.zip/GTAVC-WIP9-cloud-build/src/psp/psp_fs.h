#ifndef GTAVC_PSP_FS_H
#define GTAVC_PSP_FS_H

#include <stddef.h>

/* Finds the directory containing the user's Vice City data. */
int gtavc_psp_fs_init(void);
const char *gtavc_psp_game_root(void);

/* Open/read helpers used by the future reVC streaming layer. */
int gtavc_psp_fs_read_file(const char *relative, void *buf, size_t size, size_t *out_read);
int gtavc_psp_fs_file_exists(const char *relative);

/* Diagnostic count of files found during startup probing. */
int gtavc_psp_fs_probe(void);

#endif
