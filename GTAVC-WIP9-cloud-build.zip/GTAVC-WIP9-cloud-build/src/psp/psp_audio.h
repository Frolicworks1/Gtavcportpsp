#ifndef GTAVC_PSP_AUDIO_H
#define GTAVC_PSP_AUDIO_H
int gtavc_psp_audio_init(void);
void gtavc_psp_audio_shutdown(void);
#endif
