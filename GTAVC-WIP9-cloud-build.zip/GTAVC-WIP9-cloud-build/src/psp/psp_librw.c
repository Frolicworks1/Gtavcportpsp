#include <pspgu.h>
#include <pspgum.h>
#include <pspdisplay.h>
#include <string.h>
#include "psp_librw.h"

static unsigned int __attribute__((aligned(16))) g_list[262144];
static int g_ready;

/* GU consumes per-vertex attributes in the order enabled by vtype.
   With COLOR_8888 | VERTEX_32BITF the packed color precedes xyz. */
typedef struct {
    unsigned int color;
    float x, y, z;
} PspRwVertex;

static void draw_bootstrap_quad(void) {
    /* 2D diagnostic pass: deliberately bypasses depth/culling so a black
       screen cannot be mistaken for a renderer bring-up failure. */
    /* PSP GU vertex attributes are laid out in attribute order: color first,
       then position. A position-first struct makes GU read the wrong offsets. */
    typedef struct {
        unsigned int color;
        float x, y, z;
    } QuadVertex;
    static const QuadVertex q[] __attribute__((aligned(16))) = {
        { 0xff3030d0,   8.0f,   8.0f, 0.0f },
        { 0xff30d030, 472.0f,   8.0f, 0.0f },
        { 0xffd03030, 472.0f, 264.0f, 0.0f },
        { 0xffd0d030,   8.0f, 264.0f, 0.0f }
    };
    sceGuDisable(GU_DEPTH_TEST);
    sceGuDisable(GU_CULL_FACE);
    sceGuDisable(GU_TEXTURE_2D);
    sceGuDrawArray(GU_TRIANGLE_FAN,
                   GU_VERTEX_32BITF | GU_COLOR_8888 | GU_TRANSFORM_2D,
                   4, 0, q);
}

static void draw_cube(float a) {
    static const PspRwVertex v[] __attribute__((aligned(16))) = {
        {0xff2020ff,-1,-1,-1},{0xff20ff20, 1,-1,-1},{0xffff2020, 1, 1,-1},{0xffffffff,-1, 1,-1},
        {0xffff20ff,-1,-1, 1},{0xff20ffff, 1,-1, 1},{0xffffff20, 1, 1, 1},{0xff808080,-1, 1, 1}
    };
    static const unsigned short i[] = {
        0,1,2, 0,2,3, 4,6,5, 4,7,6, 0,4,5, 0,5,1,
        3,2,6, 3,6,7, 0,3,7, 0,7,4, 1,5,6, 1,6,2
    };

    sceGuDisable(GU_DEPTH_TEST);
    sceGuDisable(GU_CULL_FACE);
    sceGumMatrixMode(GU_PROJECTION);
    sceGumLoadIdentity();
    sceGumPerspective(55.0f, 480.0f / 272.0f, 0.5f, 100.0f);
    sceGumMatrixMode(GU_VIEW);
    sceGumLoadIdentity();
    ScePspFVector3 pos = {0.0f, 0.0f, -5.0f};
    sceGumTranslate(&pos);
    sceGumRotateY(a);
    sceGumRotateX(a * 0.61f);
    sceGumMatrixMode(GU_MODEL);
    sceGumLoadIdentity();
    sceGumDrawArray(GU_TRIANGLES,
                    GU_INDEX_16BIT | GU_VERTEX_32BITF | GU_COLOR_8888 | GU_TRANSFORM_3D,
                    sizeof(i) / sizeof(i[0]), i, v);
}

int gtavc_psp_librw_init(void) {
    if (g_ready) return 0;
    sceGuInit();
    sceGuStart(GU_DIRECT, g_list);
    sceGuDrawBuffer(GU_PSM_8888, (void*)0, 512);
    sceGuDispBuffer(480, 272, (void*)0x88000, 512);
    sceGuDepthBuffer((void*)0x110000, 512);
    sceGuOffset(2048 - 240, 2048 - 136);
    sceGuViewport(2048, 2048, 480, 272);
    sceGuDepthRange(65535, 0);
    sceGuScissor(0, 0, 480, 272);
    sceGuEnable(GU_SCISSOR_TEST);
    sceGuDisable(GU_DEPTH_TEST);
    sceGuDepthFunc(GU_GEQUAL);
    sceGuDisable(GU_CULL_FACE);
    sceGuFrontFace(GU_CW);
    sceGuShadeModel(GU_SMOOTH);
    sceGuDisable(GU_TEXTURE_2D);
    sceGuFinish();
    sceGuSync(0, 0);
    sceDisplayWaitVblankStart();
    sceGuDisplay(GU_TRUE);
    g_ready = 1;
    return 0;
}

void gtavc_psp_librw_shutdown(void) {
    if (!g_ready) return;
    sceGuDisplay(GU_FALSE);
    sceGuTerm();
    g_ready = 0;
}

void gtavc_psp_librw_begin_frame(void) {
    sceGuStart(GU_DIRECT, g_list);
    sceGuClearColor(0xff101018);
    sceGuClearDepth(0);
    sceGuClear(GU_COLOR_BUFFER_BIT | GU_DEPTH_BUFFER_BIT);
    draw_bootstrap_quad();
}

void gtavc_psp_librw_end_frame(void) {
    sceGuFinish();
    sceGuSync(0, 0);
    sceDisplayWaitVblankStart();
    sceGuSwapBuffers();
}

void gtavc_psp_librw_draw_bootstrap(float angle) {
    draw_cube(angle);
}
