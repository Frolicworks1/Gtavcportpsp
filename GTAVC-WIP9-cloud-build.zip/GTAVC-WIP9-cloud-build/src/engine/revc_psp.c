#include <pspiofilemgr.h>
#include <pspkernel.h>
#include <stdio.h>
#include <string.h>
#include "revc_psp.h"
#include "../psp/psp_fs.h"
#include "../psp/psp_img.h"
#include "../psp/psp_librw.h"

static int g_data;
static int g_img;
static float g_angle;
static SceUID g_log_fd = -1;
static unsigned int g_frames;
static unsigned int g_last_report_ms;

static unsigned int now_ms(void) {
    return (unsigned int)(sceKernelGetSystemTimeWide() / 1000ULL);
}
static void log_line(const char *line) {
    if (g_log_fd >= 0 && line) {
        sceIoWrite(g_log_fd, line, strlen(line));
        sceIoWrite(g_log_fd, "\n", 1);
        sceIoSync(".", 0);
    }
}

int gtavc_revc_psp_init(void) {
    char line[192];
    gtavc_psp_fs_init();
    {
        char log_path[512];
        snprintf(log_path, sizeof(log_path), "%s/gtavc_runtime.log", gtavc_psp_game_root());
        g_log_fd = sceIoOpen(log_path, PSP_O_WRONLY | PSP_O_CREAT | PSP_O_TRUNC, 0777);
    }
    snprintf(line, sizeof(line), "GTAVC PSP runtime start; data_root=%s", gtavc_psp_game_root());
    log_line(line);
    g_data = gtavc_psp_fs_probe();
    snprintf(line, sizeof(line), "data probe found %d known files", g_data);
    log_line(line);
    g_img = gtavc_psp_img_open("models/gta3.img");
    snprintf(line, sizeof(line), "gta3 archive index result=%d", g_img);
    log_line(line);
    if (g_img < 0) g_img = 0;
    int gu_result = gtavc_psp_librw_init();
    snprintf(line, sizeof(line), "GU init result=%d", gu_result);
    log_line(line);
    g_last_report_ms = now_ms();
    return gu_result;
}

void gtavc_revc_psp_frame(void) {
    /* This remains a GU bring-up frame, not the real reVC game loop. */
    gtavc_psp_librw_begin_frame();
    gtavc_psp_librw_draw_bootstrap(g_angle);
    gtavc_psp_librw_end_frame();
    g_angle += 0.01f;
    ++g_frames;
    if (g_frames % 300 == 0) {
        unsigned int now = now_ms();
        char line[128];
        unsigned int elapsed = now - g_last_report_ms;
        unsigned int fps_x100 = elapsed ? (30000u / elapsed) : 0;
        snprintf(line, sizeof(line), "frame=%u approx_fps=%u.%02u", g_frames,
                 fps_x100 / 100, fps_x100 % 100);
        log_line(line);
        g_last_report_ms = now;
    }
}

void gtavc_revc_psp_shutdown(void) {
    gtavc_psp_img_close();
    gtavc_psp_librw_shutdown();
    log_line("GTAVC PSP runtime shutdown");
    if (g_log_fd >= 0) sceIoClose(g_log_fd);
    g_log_fd = -1;
}

int gtavc_revc_psp_data_ready(void) { return g_data; }
int gtavc_revc_psp_img_entries(void) { return g_img; }
