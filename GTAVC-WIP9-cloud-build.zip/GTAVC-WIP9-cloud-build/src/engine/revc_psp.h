#ifndef GTAVC_REVC_PSP_H
#define GTAVC_REVC_PSP_H

int gtavc_revc_psp_init(void);
void gtavc_revc_psp_frame(void);
void gtavc_revc_psp_shutdown(void);
int gtavc_revc_psp_data_ready(void);
int gtavc_revc_psp_img_entries(void);

#endif
