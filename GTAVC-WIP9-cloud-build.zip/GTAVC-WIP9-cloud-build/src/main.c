#include <pspkernel.h>
#include <pspdebug.h>
#include <pspctrl.h>
#include "engine/revc_psp.h"
#include "psp/psp_input.h"
#include "psp/psp_audio.h"
#include "psp/psp_save.h"

PSP_MODULE_INFO("GTAVC-PSP", 0, 1, 0);
PSP_MAIN_THREAD_ATTR(PSP_THREAD_ATTR_USER | PSP_THREAD_ATTR_VFPU);
PSP_HEAP_SIZE_KB(-1);

int module_start(SceSize args, void *argp) {
    (void)args; (void)argp;
    pspDebugScreenInit();
    gtavc_psp_input_init();
    gtavc_psp_audio_init();
    gtavc_psp_save_init();
    gtavc_revc_psp_init();
    for (;;) {
        SceCtrlData pad = gtavc_psp_input_read();
        if (pad.Buttons & PSP_CTRL_START) break;
        gtavc_revc_psp_frame();
    }
    gtavc_revc_psp_shutdown();
    gtavc_psp_audio_shutdown();
    sceKernelExitGame();
    return 0;
}

int main(int argc, char **argv) { (void)argc; (void)argv; return module_start(0, 0); }
