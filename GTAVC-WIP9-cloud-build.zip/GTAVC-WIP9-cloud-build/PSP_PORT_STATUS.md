# GTAVC PSP build status — WIP5 / real-engine integration pass

## What changed
- Hardened the PSP GU bring-up path so depth/culling cannot hide the diagnostic geometry.
- Added a full-source acquisition script for the public `re3fork/re3-miami-vita` reVC tree and its submodules.
- Added a PSP cross-compile harness that enumerates the real reVC C/C++ source tree and reports the first MIPS/PSP compiler failure in dependency order.
- Added a concrete integration plan for replacing the desktop platform/renderer with PSP skeleton + GU/librw backend.

## Verified here
- Clean PSPDEV build succeeds.
- `GTAVC.elf` is MIPS-II/Allegrex ELF32.
- `EBOOT.PBP` packages successfully.
- The diagnostic GU path now draws a 2D quad before the 3D test, so a black framebuffer is not silently accepted as a renderer test pass.

## Important truth
This EBOOT is **not yet playable Vice City**. The previous build only contained a PSP renderer bring-up test. Full reVC + librw integration is the next build stage and is now wired into the project as an actual source acquisition and cross-compilation path.

## Target
Continue until the real reVC engine is linked, DFF/TXD/IMG streaming works with the user's external Vice City data, PPSSPP shows the game, and then optimize toward the 30–40 FPS target where feasible.
