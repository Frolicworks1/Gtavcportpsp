# WIP8 rendering fix report

## Root causes corrected in the diagnostic renderer

1. **Indexed cube draw omitted `GU_INDEX_16BIT`.** The index array was passed to `sceGumDrawArray`, but the vertex type did not declare 16-bit indices. The GU could treat the index pointer incorrectly and fetch vertices out of bounds, which is consistent with long diagonal/pink artifacts and unstable output.
2. **Vertex attribute memory layout was wrong.** The enabled attributes are color and xyz, but the diagnostic structs stored xyz before color. The vertex records now put `GU_COLOR_8888` first, followed by `GU_VERTEX_32BITF` coordinates, matching PSP GU attribute ordering.

Both the 2D diagnostic quad and 3D diagnostic cube use the corrected color/position layout. The cube draw call explicitly declares `GU_INDEX_16BIT`.

## Verification limits

- Source-level checks confirm the expected index flag and attribute layout are present.
- This environment does not have `psp-gcc`, `psp-g++`, `mksfoex`, or `pack-pbp`; no new EBOOT was compiled.
- PPSSPP is not available here, so the screenshot symptom cannot be confirmed fixed until this source is rebuilt and run in the user's emulator.
- This remains a diagnostic renderer. It is not the full reVC game engine and is not a playable Vice City build.
