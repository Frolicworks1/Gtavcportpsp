# Real reVC -> PSP integration pass

This WIP does not pretend the current cube is Vice City. The next build path is now tied to the public reVC/Vita source tree.

## Why the screen can still be black
The current EBOOT is a PSP GU bring-up program. It does not contain the real Vice City engine. A successful MIPS link only proves the PSP module can start; it does not prove reVC rendering is connected.

## Real integration path
1. `tools/fetch_full_revc.sh` clones the public `re3fork/re3-miami-vita` source and its submodules.
2. `tools/build_full_revc_psp.sh` enumerates the actual reVC C/C++ translation units.
3. Desktop skeletons are excluded. PSP replacements are compiled instead.
4. Compiler errors are fixed in dependency order: platform types -> file/timer/input -> RenderWare API -> librw renderer -> audio -> linker.
5. The final link uses the PSP GU backend and produces the real MIPS `GTAVC.elf`.
6. `pack-pbp` produces the EBOOT.
7. User-owned GTA Vice City files remain external under the existing PSP data root.

## Renderer target
The reVC engine expects librw interfaces, not a cube-specific renderer. The PSP backend must implement the librw raster/texture/geometry state using `sceGu*`/`sceGum*`, with texture memory and streaming budgets sized for PSP RAM.

The PSVita reVC port is used only as a platform-reference because it already separates the reVC engine from the platform layer. It is not treated as a PSP binary or a drop-in PSP renderer.
