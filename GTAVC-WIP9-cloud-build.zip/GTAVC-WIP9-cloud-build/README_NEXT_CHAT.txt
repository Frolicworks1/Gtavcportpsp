WIP6 NEXT LOOP

1. On a networked machine: ./tools/fetch_full_revc.sh
2. Set PSPDEV and PSPSDK.
3. Run CONTINUE_ON_ERROR=1 ./tools/build_full_revc_psp.sh
4. Fix/replace the grouped MIPS errors in build/revc-psp/errors.log.
5. Build librw GU backend, then link real reVC engine.
6. Pack EBOOT.PBP.
7. Test in PPSSPP with user-owned GTA Vice City assets.

Do not call the diagnostic cube a playable game.
