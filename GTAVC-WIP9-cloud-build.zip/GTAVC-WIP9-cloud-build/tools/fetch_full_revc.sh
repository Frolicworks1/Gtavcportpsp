#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
cd "$ROOT"
mkdir -p third_party

if [ ! -d third_party/re3-miami-vita/.git ]; then
  git clone --recursive --depth 1 https://github.com/re3fork/re3-miami-vita.git third_party/re3-miami-vita
else
  git -C third_party/re3-miami-vita fetch --depth 1 origin main
  git -C third_party/re3-miami-vita reset --hard FETCH_HEAD
  git -C third_party/re3-miami-vita submodule update --init --recursive
fi

printf '%s\n' 'Full reVC/Vita reference source is ready.'
printf '%s\n' 'This is the source base used for the PSP integration pass; no game assets are copied.'
