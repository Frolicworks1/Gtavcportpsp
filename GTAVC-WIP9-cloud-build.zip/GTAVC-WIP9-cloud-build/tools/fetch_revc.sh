#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
REVCDIR="$ROOT/third_party/reVC"
if [ ! -d "$REVCDIR/.git" ]; then
  git clone --depth 1 --branch miami --recurse-submodules https://github.com/mrxenginner/reVC.git "$REVCDIR"
else
  git -C "$REVCDIR" fetch --depth 1 origin miami
  git -C "$REVCDIR" reset --hard FETCH_HEAD
  git -C "$REVCDIR" submodule update --init --recursive
fi
printf 'reVC source ready at %s\n' "$REVCDIR"
