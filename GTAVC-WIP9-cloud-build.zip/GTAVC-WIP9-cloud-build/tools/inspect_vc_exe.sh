#!/bin/sh
set -eu
EXE=${1:-gta-vc.exe}
if [ ! -f "$EXE" ]; then echo "Missing $EXE" >&2; exit 2; fi
file "$EXE"
echo '--- RenderWare / streaming references ---'
strings -a "$EXE" | grep -E -i 'RenderWare|CdStream|GTA3\.IMG|TXD\.IMG|CUTS\.IMG|paths\.dat|PARTICLE\.TXD|ANIM\\PED\.IFP' | sort -u || true
echo '--- Windows graphics/audio imports (if objdump supports PE) ---'
objdump -p "$EXE" 2>/dev/null | grep -E 'DLL Name|d3d8|dinput|dsound|winmm|mss32' || true
