#!/bin/sh
set -u
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
cd "$ROOT"
: "${PSPDEV:?Set PSPDEV}"; : "${PSPSDK:?Set PSPSDK}"
export PATH="$PSPDEV/bin:$PSPSDK/bin:$PATH"
REV=${REVC_SOURCE:-$ROOT/third_party/re3-miami-vita}
LIB=${LIBRW:-$REV/vendor/librw}
BUILD="$ROOT/build/revc-psp"
mkdir -p "$BUILD/obj" "$BUILD/logs"
if [ ! -d "$REV/src" ]; then
  echo "REVC_SOURCE is missing: $REV" >&2
  echo "On the iMac run: ./tools/fetch_full_revc.sh" >&2
  exit 2
fi
if [ ! -d "$LIB" ]; then
  echo "LIBRW source is missing: $LIB" >&2
  exit 3
fi
find "$REV/src" -type f \( -name '*.c' -o -name '*.cpp' \) \
  ! -path '*/skel/win/*' ! -path '*/skel/glfw/*' ! -path '*/skel/sdl2/*' \
  ! -path '*/skel/android/*' ! -path '*/skel/vita/*' > "$BUILD/revc.sources"
find "$LIB/src" -type f \( -name '*.c' -o -name '*.cpp' \) > "$BUILD/librw.sources" 2>/dev/null || true
: > "$BUILD/compile.log"
: > "$BUILD/errors.log"
CXXFLAGS='-O2 -G0 -msoft-float -fno-exceptions -fno-rtti -ffast-math -fno-strict-aliasing -Wall -Wno-unused-function'
DEFS='-DPSP -DMIAMI -DLIBRW -DMASTER -DFINAL -DNO_DINPUT -DGTAVC_PSP'
N=0; E=0
compile_one(){
  src="$1"; rel="$2"; obj="$BUILD/obj/${rel%.*}.o"; mkdir -p "$(dirname "$obj")"
  echo "[PSP-CXX] $rel"
  if ! psp-g++ $CXXFLAGS $DEFS -I"$REV/src" -I"$REV/src/fakerw" -I"$LIB" -I"$LIB/src" -I"$ROOT/src/psp" -c "$src" -o "$obj" >>"$BUILD/compile.log" 2>&1; then
    E=$((E+1)); { echo "===== $rel ====="; tail -n 60 "$BUILD/compile.log"; } >> "$BUILD/errors.log"
    return 1
  fi
  N=$((N+1)); return 0
}
while IFS= read -r src; do rel=${src#"$REV/src/"}; compile_one "$src" "$rel" || [ "${CONTINUE_ON_ERROR:-1}" = 1 ] || exit 10; done < "$BUILD/revc.sources"
while IFS= read -r src; do rel="librw/${src#"$LIB/src/"}"; compile_one "$src" "$rel" || [ "${CONTINUE_ON_ERROR:-1}" = 1 ] || exit 11; done < "$BUILD/librw.sources"
printf 'Compiled objects: %s\nCompiler-error translation units: %s\n' "$N" "$E"
if [ "$E" -ne 0 ]; then echo "See $BUILD/errors.log"; exit 10; fi
echo 'All reVC+librw translation units compiled. Link stage is next.'
