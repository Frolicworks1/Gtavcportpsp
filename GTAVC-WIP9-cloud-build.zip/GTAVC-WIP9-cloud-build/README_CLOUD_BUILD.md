# Cloud build guide (no Mac required)

This repository currently builds the **PSP GU diagnostic renderer**, not a playable Vice City game. The workflow compiles the current source into a fresh `EBOOT.PBP` so you can test source changes instead of repeatedly launching an older EBOOT.

## Build on GitHub Actions
1. Create a new GitHub repository.
2. Upload the *contents* of this folder to the repository root (the `Makefile` should be at the root).
3. Open **Actions** and enable workflows if prompted.
4. Select **Build PSP diagnostic EBOOT** and choose **Run workflow**. A push to `main` or `master` also triggers it.
5. When the run finishes, open it and download the `GTAVC-PSP-diagnostic-EBOOT` artifact.
6. Extract `EBOOT.PBP` and copy it to `PSP/GAME/GTAVC/EBOOT.PBP` on your device.

## Important limitation
The EBOOT produced by this workflow is a diagnostic GU renderer test. It does not contain the actual reVC game engine, complete `librw` PSP backend, or Vice City gameplay. A successful compile proves only that this diagnostic source builds; it does not prove the game is playable or that the visual bug is fixed. Test the new artifact, not the old EBOOT, before reporting results.
