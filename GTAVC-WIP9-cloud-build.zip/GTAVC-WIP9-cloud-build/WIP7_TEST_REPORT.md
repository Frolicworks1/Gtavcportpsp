# WIP7 source-fix test report

## Confirmed against supplied Vice City data
- `models/gta3.dir` is 193,376 bytes, exactly 6,043 entries of 32 bytes each.
- The last entry (`van.ifp`) starts at sector 159,867 and reserves 39 sectors.
- All 6,043 directory entries fit within the supplied `models/gta3.img` size (327,487,488 bytes).
- The prior WIP6 loader incorrectly attempted to parse 32-byte directory records from the binary `.img` payload; WIP7 now opens the paired `.dir` index and keeps `.img` for entry data reads.

## Not verified
- PSP cross-compilation: unavailable here (`psp-gcc`, `psp-g++`, `mksfoex`, `pack-pbp` not installed).
- PPSSPP execution: not available in this environment.
- Full gameplay: not implemented. `src/engine/revc_psp.c` still calls the diagnostic GU quad/cube path; real reVC and full librw GU rendering are not integrated.
- The existing `EBOOT.PBP` and `GTAVC.elf` are unchanged WIP6 artifacts and do not include the WIP7 source fix.

## Host-side functional test of the archive reader
- Compiled `src/psp/psp_img.c` with strict C99 warnings (`-Wall -Wextra -Werror`) against a small POSIX shim for PSP file I/O.
- Opened the supplied real archive: `entries=6043`.
- Located `van.ifp` at sector `159867`, allocation `39` sectors.
- Read its first 16 bytes successfully; signature begins `41 4e 50 4b` (`ANPK`).
- This validates the corrected `.dir` index + `.img` data access logic on the supplied files, but is not a PSP or PPSSPP test.
