#!/bin/sh
set -eu
: "${PSPDEV:?Set PSPDEV}"
: "${PSPSDK:?Set PSPSDK}"
export PATH="$PSPDEV/bin:$PATH"
make clean
make -j2
[ -f EBOOT.PBP ]
echo "Built EBOOT.PBP"
